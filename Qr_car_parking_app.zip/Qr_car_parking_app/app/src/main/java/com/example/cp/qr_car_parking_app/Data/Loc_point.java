package com.example.cp.qr_car_parking_app.Data;

public class Loc_point {

    public  static double lat=0.0,lon=0.0;

    public static double getLat() {
        return lat;
    }

    public static void setLat(double lat) {
        Loc_point.lat = lat;
    }

    public static double getLon() {
        return lon;
    }

    public static void setLon(double lon) {
        Loc_point.lon = lon;
    }

}
