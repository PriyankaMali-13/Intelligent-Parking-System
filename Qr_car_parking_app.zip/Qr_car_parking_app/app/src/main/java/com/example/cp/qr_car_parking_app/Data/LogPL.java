package com.example.cp.qr_car_parking_app.Data;

public class LogPL
{

    public static String areaId;
    public static String areaName;
    public static String mail;

    public static String getAreaId() {
        return areaId;
    }

    public static String getAreaName() {
        return areaName;
    }

    public static String getMail() {
        return mail;
    }

    public static void setAreaId(String areaId) {
        LogPL.areaId = areaId;
    }

    public static void setAreaName(String areaName) {
        LogPL.areaName = areaName;
    }

    public static void setMail(String mail) {
        LogPL.mail = mail;
    }

}
